// KinectProject.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <Windows.h>
#include <NuiApi.h>
#include <stdlib.h>
#include <chrono>
#include "Detector.h"
#include <string>

using namespace std;

LPTSTR mutexname = TEXT("SwipeTextAccess");
void writeToFile(ofstream& channel, string filename, string txt);

int main()
{
	NuiInitialize(NUI_INITIALIZE_FLAG_USES_SKELETON);
	NUI_SKELETON_FRAME frame;
	Detector detector;
	ofstream myFile;

	//myFile.open("./testVariables.txt");
	//string mutexname = "SwipeTextAccess";
	cout << "START" << endl;

	HANDLE WINAPI mutex = CreateMutex(NULL, false, mutexname);

	if (mutex == NULL)
		cout << "MUTEX ERROR" << endl;

	ReleaseMutex(mutex);

	while (1) //For all of time
	{
		NuiSkeletonGetNextFrame(0, &frame); //Get a frame and stuff it into ourframe
		for (int i = 0; i < 6; i++) //Six times, because the Kinect has space to track six people
		{
			//myFile.open("./testVariables.txt");

			detector.excavate(frame.SkeletonData[i]);

			if(frame.SkeletonData[i].eTrackingState == NUI_SKELETON_TRACKED)
			{

				if (detector.detectWave())
				{
					writeToFile(myFile, "./testVariables.txt", "H");
				}
				if (detector.detectSwipeLeft())
				{
					writeToFile(myFile, "./testVariables.txt", "L");
				}
				if (detector.detectSwipeRight())
				{
					writeToFile(myFile, "./testVariables.txt", "R");
				}
				if (detector.detectSwipeUp())
				{
					writeToFile(myFile, "./testVariables.txt", "U");
				}
				if (detector.detectSwipeDown())
				{
					writeToFile(myFile, "./testVariables.txt", "D");
				}
				if (detector.detectSwipeBack())
				{
					writeToFile(myFile, "./testVariables.txt", "B");
				}

			}

		}

	}

	//myFile.close();
	//remove("testVariables.txt");

	NuiShutdown();
	return 0;
}

void writeToFile(ofstream& channel, string filename, string txt)
{
	HANDLE mutexTemp = OpenMutex(MUTEX_ALL_ACCESS, false, mutexname);
	if (mutexTemp == NULL)
		cout << "E" << endl;
	else
	{
		channel.open(filename);
		cout << txt << endl;
		channel << txt << endl;
		channel.close();
		ReleaseMutex(mutexTemp);
	}
}